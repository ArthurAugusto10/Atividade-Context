export interface LetterCtxProps {
    input: string;
    setInput: (value:string) => void;
};